import pygame, sys
from src.game import Game
from src.error_and_output import OutputLogger

logger = OutputLogger(stdout_path="my_output.log", stderr_path="my_error.log")

logger.start()

try:
    pygame.init()
    
    g = Game()
    
    while g.running:
        g.game_loop()

finally:
    logger.stop()
    pygame.quit()
    sys.exit()