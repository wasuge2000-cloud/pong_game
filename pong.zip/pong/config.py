from pathlib import Path

import pygame

pygame.init()

BASE_DIR =Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"
SRC_DIR = BASE_DIR / "src"
SPRITES_DIR = ASSETS_DIR / "sprites"
PITCH_DIR = ASSETS_DIR / "pitch"
BUTTONS_DIR =  ASSETS_DIR / "buttons"

info = pygame.display.Info()
WINDOW_W, WINDOW_H = info.current_w, info.current_h

DISPLAY_W = 1024
DISPLAY_H = 768


PITCH_W = DISPLAY_W
PITCH_H = DISPLAY_H-80

BLACK = (0, 0, 0)
WHITE =  (255, 255, 255)
