import sys
import random
import pygame

sys.stdout = open("output_log.txt", "w")
sys.stderr = open("error_log.txt", "w")

print("cake")

pygame.init()

SCREENWIDTH = 360
SCREENHEIGHT = 800

screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT),pygame.SCALED | pygame.FULLSCREEN)

class sprite(pygame.sprite.Sprite):
    def __init__(self, x, y, img):
        super().__init__()
        self.image = pygame.image.load(img).convert_alpha()
        
        # Position rect based on visual image
        self.rect = self.image.get_rect(center=(x, y))
        def get_image(self):
        return self.image
        
    def get_img_rect(self):
        return self.rect
        

class TouchObject():
    def __init__(self, sp):        
        # Inflate the hit rect by 20px on width and height to make a finger-friendly touch target
        self.touch_rect = sp.rect.inflate(20, 20)
        self.is_dragging = False
        
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            # Check touch against the larger touch_rect, not the image bounds
            if self.touch_rect.collidepoint(event.pos):
                self.is_dragging = True

        elif event.type == pygame.MOUSEBUTTONUP:
            self.is_dragging = False

        elif event.type == pygame.MOUSEMOTION and self.is_dragging:
            sp.get_rect().center = event.pos
            # Keep the touch target aligned with the object
            self.touch_rect.center = sp.get_rect().center

block = sprite(10, 10, "block.png")
touch_controls = TouchObject(block)
running = True

while running:
    screen.fill((0, 0, 0))
    events = pygame.event.get()
    for event in events:
        if event.type == pygame.QUIT:
            running = False
        block.handle_event(event)
        
    screen.blit(block.get_image(), block.get_img_rect())
    
    pygame.display.flip()
    
    
pygame.quit()