import sys
import random
import pygame

pygame.init()

SCREENWIDTH = 360
SCREENHEIGHT = 800

screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT), pygame.SCALED | pygame.FULLSCREEN)
clock = pygame.time.Clock()

class TouchObject(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("block.png").convert_alpha()
        
        self.rect = self.image.get_rect(center=(x, y))
        self.touch_rect = self.rect.inflate(20, 20)
        
        # Multi-touch tracking variables
        self.is_dragging = False
        self.finger_id = None  # Stores the ID of the specific finger grabbing this block

    def handle_event(self, event, screen_w, screen_h):
        # 1. Finger touches screen
        if event.type == pygame.FINGERDOWN:
            # Convert normalized coords (0.0 - 1.0) to screen pixel coordinates
            touch_x = event.x * screen_w
            touch_y = event.y * screen_h

            # If not already being dragged and touch falls inside touch target
            if not self.is_dragging and self.touch_rect.collidepoint(touch_x, touch_y):
                self.is_dragging = True
                self.finger_id = event.finger_id  # Assign this finger to this object

        # 2. Finger releases screen
        elif event.type == pygame.FINGERUP:
            # Only stop dragging if the releasing finger is the one controlling this block
            if self.is_dragging and event.finger_id == self.finger_id:
                self.is_dragging = False
                self.finger_id = None

        # 3. Finger moves on screen
        elif event.type == pygame.FINGERMOTION:
            # Move block only if it's being dragged BY THIS SPECIFIC FINGER
            if self.is_dragging and event.finger_id == self.finger_id:
                touch_x = event.x * screen_w
                touch_y = event.y * screen_h
                
                self.rect.center = (touch_x, touch_y)
                self.touch_rect.center = self.rect.center


# Create a list/group of blocks to test multi-touch simultaneous dragging
blocks = [
    TouchObject(50, 100),
    TouchObject(200, 100),
]

running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        # Pass touch event to all blocks
        for block in blocks:
            block.handle_event(event, SCREENWIDTH, SCREENHEIGHT)
        
    screen.fill((0, 0, 0))
    
    for block in blocks:
        screen.blit(block.image, block.rect)
    
    pygame.display.flip()
    clock.tick(60)
    
pygame.quit()
sys.exit()
