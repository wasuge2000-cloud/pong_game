import pygame

pygame.init()

def ai_logic(paddle_rect, ball_rect, speed):
    pass   
    
def paddle_movement(paddle_rect, left_btn, right_btn, speed):
    if left_btn:
        paddle_rect.x -= speed
    elif right_btn:
        paddle_rect.x += speed

def ball_wall_collision(ball_rect, pitch_rect, wall_width, dx):
    pass
        
def object_reset(ball_rect, x, y):
    ball_rect.center = (x, y)
    
def ball_floor_collision(ball_rect, pitch_rect, ball_width, object_reset, x, y):
    pass

def ball_paddle_colltision(ball_rect, paddle_rect, dy, player1 = True):
    pass
    
    
 