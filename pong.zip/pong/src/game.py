import pygame

from config import *
from src.buttons import Buttons
from src.spr import PitchWall, Balls, Paddles
class Game():
    def __init__(self):
        pygame.init()
        self.running, self.playing = True, False
        
        self.window = pygame.display.set_mode((WINDOW_W, WINDOW_H))
        self.window_rect = self.window.get_rect()
        self.win_width, self.win_height = self.window.get_size()
        self.display = pygame.Surface((DISPLAY_W, DISPLAY_H))
        self.display_rect = self.display.get_rect()
        self.display_rect.center = (self.win_width//2, self.win_height//2)
        self.dis_width, self.dis_height = self.display.get_size()
        self.pitch = pygame.Surface((PITCH_W, PITCH_H))
        self.pitch_rect = self.pitch.get_rect()
        self.pitch_rect.center = (self.dis_width // 2, (self.dis_height // 2)+30)
        self.pitch_width, self.pitch_height = self.pitch.get_size()
        self.pitch_walls = PitchWall(self)
        self.ball_group = Balls.group
        self.ball = Balls(SPRITES_DIR / "ball.png", self.pitch_width * 0.5, self.pitch_height * 0.5, self)
        self.paddle_group = Paddles.group
        self.paddle1 = Paddles(SPRITES_DIR / "paddle.png", self.pitch_width * 0.01, self.pitch_height * 0.5, self)
        self.paddle2 = Paddles(SPRITES_DIR / "paddle.png", self.pitch_width * 0.99, self.pitch_height * 0.5, self, is_ai = True)
        self.font_name = SRC_DIR / "joystix_monospace.otf"
        ui_scale_w = self.win_width / DISPLAY_W
        ui_scale_h = self.win_height / DISPLAY_H
        ui_scale_factor = min(ui_scale_w, ui_scale_h)
        self.back_btn = Buttons(BUTTONS_DIR/"back_button.png",self.win_width *0.95, self.win_height * 0.05, scale = ui_scale_factor * 0.3)
        self.press_back, self.paddle1_press_up, self.paddle1_press_down, self.paddle2_press_up, self.paddle2_press_down = False, False, False, False, False
        self.paddle1_up_btn = Buttons(BUTTONS_DIR/"up_button.png", self.win_width *0.9, self.win_height * 0.9, scale = ui_scale_factor * 1.5)
        self.paddle1_down_btn = Buttons(BUTTONS_DIR/"down_button.png", self.win_width * 0.1, self.win_height * 0.9, scale = ui_scale_factor * 1.5)
        self.paddle2_up_btn = Buttons(BUTTONS_DIR/"up_button.png", self.win_width *0.1, self.win_height * 0.1, scale = ui_scale_factor, is_visible = False)
        self.paddle2_down_btn = Buttons(BUTTONS_DIR/"down_button.png", self.win_width * 0.9, self.win_height * 0.1, scale = ui_scale_factor, is_visible = False)
        self.buttons = [self.back_btn, self.paddle1_up_btn, self.paddle1_down_btn, self.paddle2_up_btn, self.paddle2_down_btn]
        self.dt = 0
        
    def game_loop(self):
        self.playing = True
        clock = pygame.time.Clock()
        while self.playing:
            self.check_event()
            self.check_input()
            self.window.fill(BLACK)
            self.display.fill(BLACK)
            self.pitch.fill(BLACK)
            self.ball_group.update(self.paddle1, self.paddle2)
            self.paddle1.update(self.paddle1_press_up, self.paddle1_press_down)
            self.paddle2.update(False, False)
            self.ball_group.draw(self.pitch)
            self.paddle_group.draw(self.pitch)
            for btn in self.buttons:
                btn.draw(self.window)
            self.draw_text(f"{self.ball.paddle1_score}", 50, self.dis_width * 0.44 , 50)
            self.draw_text(":", 55, self.dis_width * 0.5 , 50)
            self.draw_text(f"{self.ball.paddle2_score}", 50, self.dis_width * 0.56 , 50)
            
            self.pitch_walls.draw()
            self.display.blit(self.pitch, self.pitch_rect)
            scaled_display, scaled_rect = self.scale_to(self.display)
            self.window.blit(scaled_display, scaled_rect)
            self.dt = clock.tick(60) / 1000
            pygame.display.update()
            
    def check_event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running, self.playing = False, False
        if self.press_back:
            self.playing, self.running = False, False
    
    def draw_text(self, text, size, x, y):
        font = pygame.font.Font(self.font_name, size)
        text_surface = font.render(text, True, WHITE)
        text_rect = text_surface.get_rect()
        text_rect.center = (x, y)
        self.display.blit(text_surface, text_rect)
        
    def check_input(self):
        mouse_pos = pygame.mouse.get_pos()
        if self.back_btn.press(mouse_pos):
            self.press_back = True
        else:
            self.press_back = False
        if self.paddle1_up_btn.press(mouse_pos, trigger_once = False):
            self.paddle1_press_up = True
        else:
            self.paddle1_press_up = False
        if self.paddle1_down_btn.press(mouse_pos, trigger_once = False):
            self.paddle1_press_down = True
        else:
            self.paddle1_press_down = False
        if self.paddle2_up_btn.press(mouse_pos, trigger_once = False):
            self.paddle2_press_up = True
        else:
            self.paddle2_press_up = False
        if self.paddle2_down_btn.press(mouse_pos, trigger_once = False):
            self.paddle2_press_down = True
        else:
            self.paddle2_press_down = False
    def scale_to(self, surface):
        scale_w = self.win_width / self.dis_width
        scale_h =  self.win_height / self.dis_height
        
        scale_factor = min(scale_w, scale_h)
        
        scaled_w = int(self.dis_width * scale_factor)
        scaled_h = int(self.dis_height * scale_factor)
        
        scaled_surface = pygame.transform.scale(surface, (scaled_w, scaled_h))
        scaled_rect = scaled_surface.get_rect(center=(self.win_width // 2, self.win_height // 2))
        
        return scaled_surface, scaled_rect
        
        
    
        
        