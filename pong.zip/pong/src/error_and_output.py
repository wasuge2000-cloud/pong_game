import sys
import datetime

class _FlushStream:
    """Helper wrapper to ensure every write is immediately flushed to disk."""
    def __init__(self, stream):
        self.stream = stream

    def write(self, data):
        self.stream.write(data)
        self.stream.flush()  # Flushes immediately to the file

    def flush(self):
        self.stream.flush()

    def __getattr__(self, attr):
        return getattr(self.stream, attr)

class OutputLogger:
    """Manages redirection of standard output and error streams to log files."""
    
    def __init__(self, stdout_path="output_log.txt", stderr_path="error_log.txt", timestamp=True):
        self.stdout_path = stdout_path
        self.stderr_path = stderr_path
        self.timestamp = timestamp
        
        self._orig_stdout = sys.stdout
        self._orig_stderr = sys.stderr
        self._stdout_file = None
        self._stderr_file = None

    def start(self):
        """Starts redirecting stdout and stderr to files with instant flushing."""
        self._stdout_file = open(self.stdout_path, "w")
        self._stderr_file = open(self.stderr_path, "w")
        
        if self.timestamp:
            header = f"=== Log started at {datetime.datetime.now()} ===\n\n"
            self._stdout_file.write(header)
            self._stderr_file.write(header)
            self._stdout_file.flush()
            self._stderr_file.flush()
            
        # Wrap the files in _FlushStream so errors appear instantly
        sys.stdout = _FlushStream(self._stdout_file)
        sys.stderr = _FlushStream(self._stderr_file)

    def stop(self):
        """Restores stdout and stderr to their original streams and closes files."""
        sys.stdout = self._orig_stdout
        sys.stderr = self._orig_stderr
        
        if self._stdout_file and not self._stdout_file.closed:
            self._stdout_file.close()
        if self._stderr_file and not self._stderr_file.closed:
            self._stderr_file.close()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
