import pygame

class Buttons(pygame.sprite.Sprite):
    def __init__(self, img, x, y, scale = 1, is_visible = True):
        super().__init__()
        self.img = img
        self.image = pygame.image.load(self.img).convert_alpha()
        width = self.image.get_width()
        height = self.image.get_height()
        self.image = pygame.transform.scale(self.image, (int(width * scale), int(height * scale)))
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.is_visible = is_visible
        self.clicked = False
    
    def draw(self, surface): 
        if self.is_visible:       
            surface.blit(self.image, self.rect)
        
    def press(self, mouse_pos, trigger_once = True):
        action = False
        
        if self.rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True
                action = True
        if pygame.mouse.get_pressed()[0] == 0 and self.clicked == True:
            self.clicked = False
            
        if trigger_once == True:            
            return action
            
        return self.clicked

    