import pygame
import random
class Entity(pygame.sprite.Sprite):
    def __init__(self, img, x, y, game):
        super().__init__()
        self.game = game
        self.image = pygame.image.load(img).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.mask = pygame.mask.from_surface(self.image)
        self.pitch = self.game.pitch
        self.pitch_rect = self.game.pitch_rect
        self.top_wall = self.game.pitch_walls.top_wall
        self.bottom_wall = self.game.pitch_walls.bottom_wall
        self.is_colliding = False
    def draw(self):
        self.pitch.blit(self.image, self.rect)     
    def reset(self, x, y):
        self.rect.center = (x, y)
        if hasattr(self, 'x'):
            self.x = float(self.rect.x)
        if hasattr(self, 'y'):
            self.y = float(self.rect.y)
        if hasattr(self, 'speed'):
            self.speed = 200
        if hasattr(self, 'x'):
            self.dy = 0


class PitchWall():
    def __init__(self, game):
        self.game = game
        self.pitch = self.game.pitch

        pitch_width = self.pitch.get_width()
        pitch_height = self.pitch.get_height()
        
        self.top_wall = pygame.Rect(0, 0, pitch_width, 10)
        self.bottom_wall = pygame.Rect(0, pitch_height - 10, pitch_width, 10)
        self.mid_line = pygame.Rect(pitch_width//2-5, 0, 10, pitch_height)
    def draw(self):
        pygame.draw.rect(self.pitch, (255, 255, 255), self.top_wall)
        pygame.draw.rect(self.pitch, (255, 255, 255), self.bottom_wall)
        pygame.draw.rect(self.pitch, (255, 255, 255), self.mid_line)
        


class Balls(Entity):
    group = pygame.sprite.Group()
    def __init__(self, img, x, y, game):
        super().__init__(img, x, y, game)
        Balls.group.add(self)
        self.speed = 400
        self.max_speed = 900
        self.dx = -1
        self.dy = 0
        self.x = float(self.rect.x)
        self.y = float(self.rect.y)
        self.paddle1_score = 0
        self.paddle2_score = 0
    
    def offset(self, paddle):
        paddle_offset = self.rect.centery - paddle.rect.centery
        normalized_offset = paddle_offset / paddle.rect.height
        normalized_offset = max(-1.0, min(1.0, normalized_offset)) 
        return normalized_offset
        
    def movement(self, paddle1, paddle2):
        if self.dx == -1:
            paddle = paddle1
        else:
            paddle = paddle2
        
        dt = self.game.dt
        
        velocity = min(self.speed * dt, self.max_speed * dt)
       
        self.x += self.dx * velocity
        self.y += self.dy * velocity
        
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)
        
        if pygame.sprite.collide_mask(self, paddle):
            self.dy = self.offset(paddle) * 1.5
            self.dx *= -1
            
        if self.rect.top < self.top_wall.bottom:
            self.dy *= -1
            self.speed *= 1.1
            self.rect.top = self.top_wall.bottom
            self.y = float(self.rect.y) 
            
        if self.rect.bottom > self.bottom_wall.top:
            self.dy *= -1
            self.speed *= 1.1
            self.rect.bottom = self.bottom_wall.top
            self.y = float(self.rect.y)
            
        if self.rect.x + self.rect.width< self.pitch_rect.x:
            self.reset(self.pitch_rect.width // 2, self.pitch_rect.height // 2)
            self.dx = -1
            self.paddle2_score += 1
            
        if self.rect.x  > self.pitch_rect.width:
            self.reset(self.pitch_rect.width // 2, self.pitch_rect.height // 2)
            self.dx = 1
            self.paddle1_score += 1
            
            
    def update(self, paddle1, paddle2):
        self.movement(paddle1, paddle2)
        
class Paddles(Entity):
    group = pygame.sprite.Group()
    def __init__(self, img, x, y, game, is_ai = False):
        super().__init__(img, x, y, game)
        Paddles.group.add(self)
        self.speed = 350
        self.y = float(self.rect.y)
        self.is_ai = is_ai
        self.ball = self.game.ball
    def movement(self, up_btn, down_btn):
        dt = self.game.dt
        if self.is_ai == True:
            if self.ball.dx > 0:  
                diff = (self.ball.rect.centery) - self.rect.centery
                
            
                                
                if abs(diff) > 4:
                    if diff > 0:
                        self.y += self.speed *  dt
                    else:
                        self.y -= self.speed *  dt
                    
                
                self.rect.y = round(self.y)
            else:
                pass
        else:
            if up_btn:
                self.y -= self.speed * dt
            if down_btn:
                self.y += self.speed * dt
                
            self.rect.y = round(self.y)
        min_y = self.top_wall.bottom
        max_y = self.bottom_wall.top - self.height
        self.rect.y = max(min_y, min(self.y, max_y))        
    
    def update(self, up_btn, down_btn):
        self.movement(up_btn, down_btn)